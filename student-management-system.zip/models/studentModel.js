const db = require("../config/db");

async function getAll() {
  const [rows] = await db.query("SELECT * FROM students ORDER BY id DESC");
  return rows;
}

async function getById(id) {
  const [rows] = await db.query("SELECT * FROM students WHERE id = ?", [id]);
  return rows[0];
}

async function create(student) {
  const { name, roll_no, email, course } = student;
  const [result] = await db.query(
    "INSERT INTO students (name, roll_no, email, course) VALUES (?, ?, ?, ?)",
    [name, roll_no, email, course]
  );
  return getById(result.insertId);
}

async function update(id, student) {
  const { name, roll_no, email, course } = student;
  await db.query(
    "UPDATE students SET name=?, roll_no=?, email=?, course=? WHERE id=?",
    [name, roll_no, email, course, id]
  );
  return getById(id);
}

async function remove(id) {
  const [result] = await db.query("DELETE FROM students WHERE id = ?", [id]);
  return result.affectedRows > 0;
}

module.exports = { getAll, getById, create, update, remove };