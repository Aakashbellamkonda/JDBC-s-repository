const Student = require("../models/studentModel");

function validate(body) {
  const { name, roll_no, email, course } = body;
  if (!name || !roll_no || !email || !course) {
    return "All fields are required";
  }
  return null;
}

async function getStudents(req, res) {
  try {
    res.json(await Student.getAll());
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

async function getStudent(req, res) {
  try {
    const student = await Student.getById(req.params.id);
    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

async function createStudent(req, res) {
  try {
    const error = validate(req.body);
    if (error) return res.status(400).json({ message: error });
    const student = await Student.create(req.body);
    res.status(201).json(student);
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY")
      return res.status(409).json({ message: "Roll number already exists" });
    res.status(500).json({ message: err.message });
  }
}

async function updateStudent(req, res) {
  try {
    const error = validate(req.body);
    if (error) return res.status(400).json({ message: error });
    const student = await Student.update(req.params.id, req.body);
    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY")
      return res.status(409).json({ message: "Roll number already exists" });
    res.status(500).json({ message: err.message });
  }
}

async function deleteStudent(req, res) {
  try {
    const deleted = await Student.remove(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Student not found" });
    res.json({ message: "Student deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports = { getStudents, getStudent, createStudent, updateStudent, deleteStudent };