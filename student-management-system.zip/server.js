const express = require("express");
const cors = require("cors");
const path = require("path");
const studentRoutes = require("./routes/studentRoutes");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.use("/api/students", studentRoutes);

app.get("/api/health", (req, res) => {
  res.json({ status: "OK", message: "Student Management API is running" });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});