const API="/api/students";
const form=document.getElementById("studentForm");
const list=document.getElementById("studentList");
const search=document.getElementById("search");
const message=document.getElementById("message");
const saveBtn=document.getElementById("saveBtn");
const cancelBtn=document.getElementById("cancelBtn");
let students=[];

function showMessage(text,error=false){
  message.textContent=text;
  message.style.color=error?"#dc3545":"#198754";
  setTimeout(()=>message.textContent="",2500);
}

async function loadStudents(){
  try{
    const res=await fetch(API);
    if(!res.ok) throw new Error("Could not load students");
    students=await res.json();
    render();
  }catch(e){showMessage(e.message,true)}
}

function render(){
  const q=search.value.toLowerCase();
  const filtered=students.filter(s =>
    s.name.toLowerCase().includes(q) ||
    s.roll_no.toLowerCase().includes(q) ||
    s.course.toLowerCase().includes(q)
  );
  list.innerHTML=filtered.map(s=>`
    <tr>
      <td>${s.id}</td><td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.roll_no)}</td><td>${escapeHtml(s.email)}</td>
      <td>${escapeHtml(s.course)}</td>
      <td class="actions">
        <button class="edit" onclick="editStudent(${s.id})">Edit</button>
        <button class="delete" onclick="deleteStudent(${s.id})">Delete</button>
      </td>
    </tr>`).join("");
}

function escapeHtml(value){
  return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

form.addEventListener("submit",async e=>{
  e.preventDefault();
  const id=document.getElementById("studentId").value;
  const data={
    name:document.getElementById("name").value.trim(),
    roll_no:document.getElementById("roll_no").value.trim(),
    email:document.getElementById("email").value.trim(),
    course:document.getElementById("course").value.trim()
  };
  try{
    const res=await fetch(id?`${API}/${id}`:API,{
      method:id?"PUT":"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(data)
    });
    const result=await res.json();
    if(!res.ok) throw new Error(result.message||"Request failed");
    showMessage(id?"Student updated":"Student added");
    resetForm(); loadStudents();
  }catch(e){showMessage(e.message,true)}
});

function editStudent(id){
  const s=students.find(x=>x.id===id);
  if(!s)return;
  document.getElementById("studentId").value=s.id;
  document.getElementById("name").value=s.name;
  document.getElementById("roll_no").value=s.roll_no;
  document.getElementById("email").value=s.email;
  document.getElementById("course").value=s.course;
  saveBtn.textContent="Update Student";
  cancelBtn.classList.remove("hidden");
  window.scrollTo({top:0,behavior:"smooth"});
}

async function deleteStudent(id){
  if(!confirm("Delete this student?"))return;
  try{
    const res=await fetch(`${API}/${id}`,{method:"DELETE"});
    const result=await res.json();
    if(!res.ok)throw new Error(result.message);
    showMessage(result.message); loadStudents();
  }catch(e){showMessage(e.message,true)}
}

function resetForm(){
  form.reset();
  document.getElementById("studentId").value="";
  saveBtn.textContent="Add Student";
  cancelBtn.classList.add("hidden");
}
cancelBtn.onclick=resetForm;
search.addEventListener("input",render);
loadStudents();